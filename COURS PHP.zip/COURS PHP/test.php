<?php 

$img = imagecreatetruecolor(400, 30);

    // Créez des couleurs et définissez l'arrière-plan sur blanc
    $white = imagecolorallocate($img, 255, 255, 255);
    $black = imagecolorallocate($img, 0, 0, 0);

    // dimension de l'image en pixel
    imagefilledrectangle($img, 0, 0, 399, 29, $white);

    // Le texte à dessiner
    $text = 'Test un texte...';

    // Remplacez le chemin par votre propre chemin de police
    $font = 'logo.jpg';

    // ajoute le texte
    imagettftext($img, 20, 0, 10, 20, $black, $font, $text);

    // L'utilisation de imagepng () permet d'obtenir un texte plus clair
    // par rapport à imagejpeg ()

    // créer l'image
    imagepng($img, 'path_to_file.png');

    // détruit l'image temporaire
    imagedestroy($img);

?>

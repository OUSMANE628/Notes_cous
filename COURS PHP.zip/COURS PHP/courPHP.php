<?php
    $servername = "localhost";
    $password   = "";
    $DBname     = "verify_user_connect";

    // Créer une connexion
    $conn = mysqli_connect($servername, $password, $DBname);

    // Vérifier la connexion
    if ($conn->connect_error) {
        die("La connexion a échoué: " . $conn->connect_error);
    } 
    echo "Connecté avec succès";
    // ip du client
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
    $ip = $_SERVER['REMOTE_ADDR'];
    }
                                                               
    // time actuel
    $time = time();

    // on recherche l’utilisateur
    $sql_query = "SELECT * FROM connectes where ip='$ip'";
    $result = $connectBD->query($sql_query);
                                                               
    // si l'utilisateur n'est pas deja dans la table
    if($result->num_rows == 0)
    {
    $sql_query = "INSERT INTO connectes VALUES ('$ip', '$time')";
    $result = $connectBD->query($sql_query);
                                                                   

    }
    // mise-à-jour
    else
    {
    $sql_query = "UPDATE connectes SET derniere='$time' WHERE ip='$ip'";
                                                                   
    $result = $connectBD->query($sql_query);
                                                                   
    }
                                                               
    // temps d'incativité
    $time -= $temps * 60;
                                                               
    // on supprime ceux qui n'ont pas été connectés depuis assez longtemps
    $sql_query = "DELETE LOW_PRIORITY FROM connectes WHERE derniere <= $time";
    $result = $connectBD->query($sql_query);
                                                               
    /*******************
    Affichage des connectés
    *******************/

    $sql_query = "SELECT count(*) FROM connectes";
    $result = $connectBD->query($sql_query);

                                                                                   
    if($result)
    {
    $visiteurs = mysqli_fetch_array($result);
    echo '<li><br />Connect&eacute;s: ' . $visiteurs[0].'</li>';
                                  
    }
?>


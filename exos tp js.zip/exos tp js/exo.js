function changement(classe, valeur){
  let fruits = document.getElementsByClassName(classe);
  for(let i =0; i< fruits.length; i++){
    fruits[i].style.display = valeur;
  }
}

document.getElementById('tous').onclick = function(){
  changement('fruit', 'block');
  alert('vous avez cliquer pour afficher tous les fruits')
}

document.getElementById('legume').onclick = function(){
  changement('fruit', 'none');
  changement('legume', 'block');
}

document.getElementById('desert').onclick = function(){
  changement('fruit', 'none');
  changement('desert', 'block');
}

document.getElementById('dis').innerHTML;
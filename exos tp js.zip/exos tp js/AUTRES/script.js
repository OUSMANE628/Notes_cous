// console.dir(document.getElementById('premier-paragraphe'));
// console.log(document.getElementById('nom').type); //pour récupérer le type 
// console.log(document.getElementById('nom').value); //pour récupérer le nom.


// let button;
// button = document.getElementById('mon-bouton');
// console.log(button);
// button.onclick = function direBonjour() {
//     alert('bonjour !');
// };

// document.getElementById('mon-bouton').onclick = function () {
//     let nbr1 = document.getElementById('premier-nombre').value;
//     let nbr2 = document.getElementById('deuxieme-nombre').value;
//     let resultat = parseInt(nbr1) + parseInt(nbr2);
//     document.getElementById('resultat').value = resultat;
//     alert ('la somme du nbr1 et nbr2 est :'resultat);
// }

// // pour cacher le paragraphe hidden
// var element = document.getElementById('second');
// element.classList.remove('hidden');


// pour cacher les paragraphes spoiler
// let elements = document.getElementsByClassName('spoiler');
// document.getElementById('mon-bouton').onclick = function () {
//     for (var i = 0; i < elements.length; i++) {
//         var element = elements[i]; 
//         element.classList.add('hidden');
//    }
// }

// pour changer la couleur du paragraphe au quand l'utilisateur cliq dessus
// var element = document.getElementById('premier');
// element.style.backgroundColor = 'red';

// alert('bonjour');

// document.getElementById('prenom').value = 'nouveau prénom';


// let button;
//  button = document.getElementById('pouet');
//  button.onclick = function cliq() {
//      alert('cliquer ici !');
//  };

//  let elements = document.getElementsByClassName('cliq');
//  document.getElementById('mon-bouton').onclick = function () {
//     for (var i = 0; i < elements.length; i++) {
//         var element = elements[i]; 
//         element.classList.add('hidden');
//     }
// }

// var element = document.getElementsByClassName('second');

// element.onclick = function() {
//   element.style.backgroundColor = 'yellow';
// };


// pour signaler le bouton et le contenu du bouton cliquer
// var button = document.getElementsByTagName('button');
// for (var i = 0; i < button.length; i++) {
//   button[i].onclick = function (event) {
//     alert('bouton clické: ' + event.currentTarget.innerHTML);
//     // => le contenu du bouton clické va être affiché dans l'alert
//   };
// }


// pour supprimer le contenue saisie dans un input en tapant entrée sur le clavier
// var cliq = document.getElementById('cliq');
// cliq.onkeydown = function (event) {
//   console.log(event)
//   if (event.key === 'Enter') {
//     cliq.value = '';
//   }
// }


// pour mettre une backgroundcolor jaune lorqu'on cliq sur le bouton
// let elements =document.getElementsByTagName('button');
// for (let i = 0; i < elements.length; i++) {
//   elements[i].onclick = function (event) {
//     let parent =event.currentTarget.parentNode;
//     console.log(event);
//   parent.style.backgroundColor ='yellow';
//   }
// }

// pour créer deux boutons ecrire dans l'un et l'autre pour effacer
// let rect = document.createElement('input');
// let efface = document.createElement('button');
// efface.appendChild(document.createTextNode('effacer'));
// document.body.appendChild(rect);
// document.body.appendChild((efface));
// efface.onclick = function(){
//   rect.value ='';
// };


var xhr = new XMLHttpRequest(); 
xhr.open('GET',  'https://httpbin.org/ip');
xhr.onreadystatechange = function() {
  if (xhr.readyState === 4) {
    alert(xhr.responseText);
  }
};
xhr.send();

// pour verifier Mon APPID sur le navigateur
// // https://api.openweathermap.org/data/2.5/weather?lat=35&lon=35&appid=4a138514495ac0b7e88572145cab1d27



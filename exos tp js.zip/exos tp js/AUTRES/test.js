document.getElementById('bouton').onclick = function () {
    for (var i = 0; i < bouton.length; i++) {
        bouton[i].onclick = function () {
            alert('vous avez cliqué sur le bouton nº' + i);
        }
    }
}

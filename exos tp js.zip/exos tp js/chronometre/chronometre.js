let debut = document.querySelector('.tim');
let [milliseconds, sec, min, heure] = [0, 0, 0, 0];
let id;

document.getElementById('top').onclick = function () {
    if (id !== null) {
        clearInterval(id); // stopper un intervalle deja en cours en faisant le lien avec id de interval en cours
    }
    id = setInterval(chrono, 10); // lance la fonction chrono toutes les 10 milliemedeseconde à infini
}

document.getElementById('pause').onclick = function() {
    clearInterval(id);
}

document.getElementById('efface').onclick = function() {
    clearInterval(id);
    [milliseconds, sec, min, heure] = [0, 0, 0, 0];
    debut.innerHTML = '00 : 00 : 00 : 000 ';
};

function chrono() {
    milliseconds += 10;
    if (milliseconds >= 1000) {
        milliseconds = 0;
        sec++;
        if (sec >= 60) {
            sec = 0;
            min++;
            if (min >= 60) {
                min = 0;
                heure++;
            }
        }
    }

    let h = heure < 10 ? "0" + heure : heure;
    let m = min < 10 ? "0" + min : min;
    let s = sec < 10 ? "0" + sec : sec;
    let ms = milliseconds < 10 ? "00" + milliseconds : milliseconds < 100 ? "0" + milliseconds : milliseconds;

    debut.innerHTML = ` ${h} : ${m} : ${s} : ${ms}`;
}

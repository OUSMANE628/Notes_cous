let noms = document.querySelector('#nom');
let email = document.querySelector('#email');
let password = document.querySelector('#password');
let confirmpassword = document.querySelector('#confirmpassword');
let envoyer = document.querySelector('#envoyer');

let verifnom = () =>{
    let valid = false;
    let min = 3;
    let max = 20;
    let nom = noms.value.trim();
    if(!isRequired(nom)){
        showError(noms, 'le nom n\'est peux pas etre vide');
    }else if(!isBetween(nom.length, min, max)) {
        showError(noms, `le nom doit etre compris entre ${min} and ${max} caractères.`)
    }else{
        showsuccess(noms);
        valid = true;
    }return valid;

}

form.addEventListener('input', debounce(function (e) {
    switch (e.target.id) {
        case 'nom':
            verifnom();
            break;
    }
}));

var images = [
    'https://images.pexels.com/photos/104827/cat-pet-animal-domestic-104827.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=350',
    'https://images.pexels.com/photos/45201/kitty-cat-kitten-pet-45201.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=350',
    'https://images.pexels.com/photos/416160/pexels-photo-416160.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=350'
];
var indiceImage = 0;
document.getElementById('image').src = images[indiceImage];
document.getElementById('btn').onclick = function() {
  // passer à l'image suivante
  indiceImage = indiceImage + 1;
  if (indiceImage === images.length) {
    indiceImage = 0;
  }
  document.getElementById('image').src = images[indiceImage];
};
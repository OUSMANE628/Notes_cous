//creation ou importation des données via html/BDD
const bdd = [
    {
        "pseudo": 0,
        "nom" : "diallo",
        "prenom": "ousmane",
    },
    {
        "pseudo": 1,
        "nom" : "barry",
        "prenom": "oumou",
    },
    {
        "pseudo": 2,
        "nom" : "sow",
        "prenom": "ali",
    },
]


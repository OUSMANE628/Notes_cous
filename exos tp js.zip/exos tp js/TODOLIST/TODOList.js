let longeur = document.getElementsByTagName("LI");

var i;
for (i = 0; i < longeur.length; i++) {
    let span = document.createElement("SPAN");
    let txt = document.createTextNode("\u00D7");
    span.className = "ferme";
    span.appendChild(txt);
    longeur[i].appendChild(span);
}

// Click on a close button to hide the current list item
let ferme = document.getElementsByClassName("ferme");
var i;
for (i = 0; i < ferme.length; i++) {
    ferme[i].onclick = function () {
        let div = this.parentElement;
        div.style.display = "none";
    }
}

// Add a "checked" symbol when clicking on a list item
let list = document.querySelector('ul');
list.addEventListener('click', function (ev) {
    if (ev.target.tagName === 'LI') {
        ev.target.classList.toggle('selectpardefaut');
    }
}, false);

// fonction pour créer un nouveau élement quanq on cliq sur add
function AjoutElement() {
    let li = document.createElement("li");
    let inputValue = document.getElementById("titre").value;
    let t = document.createTextNode(inputValue);
    li.appendChild(t);
    if (inputValue === '') {
        alert("vous devez saisir quelque chose svp !");
    } else {
        document.getElementById("list").appendChild(li);
    }
    document.getElementById("titre").value = "";

    let span = document.createElement("SPAN");
    let txt = document.createTextNode("\u00D7");
    span.className = "ferme";
    span.appendChild(txt);
    li.appendChild(span);

    for (i = 0; i < ferme.length; i++) {
        ferme[i].onclick = function () {
            let div = this.parentElement;
            div.style.display = "none";
        }
    }
}
// let verifier = document.getElementById('val'); 

// verifier.addEventListener('click', function() { 

//   let ville = document.getElementById('ville').value;

//   let xhr = new XMLHttpRequest(); 
//   xhr.open('GET', 'https://api.openweathermap.org/data/2.5/weather?q='+ville+'&appid=4a138514495ac0b7e88572145cab1d27&units=metric&lang=fr');
//   xhr.onreadystatechange = function() {
//     if (xhr.readyState === 4) {
//       let reponse = JSON.parse(xhr.responseText);
//       alert('A ' + reponse.name + ' il fait ' + reponse.main.temp + ' degrés ')
//     }
//   };
//   xhr.send();

// })


// vérification avec la methode FETCH

let verifier = document.getElementById('val');
verifier.addEventListener('click', function () {

    let ville = document.getElementById('ville').value;

    fetch('https://api.openweathermap.org/data/2.5/weather?q=' + ville + '&appid=4a138514495ac0b7e88572145cab1d27&units=metric&lang=fr')
    .then(function (reponse) {
        console.log(reponse);
        return reponse.json();
    })
    .then(function (data) {
        console.log(data);
    })
    .catch(function (en) {
        console.log('msg', en);
    })

})



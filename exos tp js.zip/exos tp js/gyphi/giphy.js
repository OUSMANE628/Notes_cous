// let search = document.getElementById('search');
// document.getElementById('bouton').onclick = function() {
// 	let giphy = document.getElementById('giphy').value;
//     let url = 'https://api.giphy.com/v1/gifs/search?api_key=JDeAdZXVgN8g3cLbrZnHQ2a6vkmqxkvW=' + encodeURIComponent(giphy);
//   console.log('ajax request url:', url);
//   let xhr = new XMLHttpRequest(); 
//   xhr.open('GET', url);
//   xhr.onreadystatechange = function() {
//     if (xhr.readyState === 4) {
//       let reponse = JSON.parse(xhr.responseText);
//       let photos = reponse.photos.photo;
//       alert('l\'imgage saisi n\'existe pas');
//       search.innerHTML = ''; 
//       for (let i = 0; i < photos.length; i++) {
//         let photo = photos[i];

//         let photoUrl = 'https://farm' + photo.farm + '.staticflickr.com/' + photo.server + '/' + photo.id + '_' + photo.secret + '.jpg';
//         let img = document.createElement('img');
//         img.src = photoUrl;
//         search.appendChild(img);
//       }
//     }
//   };
//   xhr.send();


let api = 'https://api.giphy.com/v1/gifs/search?';
let apiKey = '&api_key=JDeAdZXVgN8g3cLbrZnHQ2a6vkmqxkvW';
let query = '&q=ryan';

function setup(){
    noCanvas();
    let url = api + apiKey + query;
    loadJSON(url, gotDATA);
}

function gotDATA(giphy){
    for(let i =0; i < giphy.data.length; i++ ){
        craeateImg(giphy.data[i].images.original.url);
    }
}
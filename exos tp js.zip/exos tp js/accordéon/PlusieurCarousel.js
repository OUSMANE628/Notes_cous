function initialiseAccordeon(element) {

    let titres = document.getElementsByClassName('titre');
    let paragraphes = document.getElementsByClassName('paragraphe');

    function afficherparagraphe(i) {
        paragraphes[i].classList.add('visible');
    }

    function cacherparagraphe() {
        for (let i = 0; i < paragraphes.length; i++) {
            paragraphes[i].classList.remove('visible')
        }
    }

    function afficher(i) {
        return function () {
            cacherparagraphe();
            afficherparagraphe(i);

        }
    }
    for (let i = 0; i < titres.length; i++) {
        titres[i].onclick = afficher(i);
    }
}

var accordeons = document.getElementsByClassName('accordeon');
for (var i = 0; i < accordeons.length; i++) {
    initialiseAccordeon(accordeons[i]);
}

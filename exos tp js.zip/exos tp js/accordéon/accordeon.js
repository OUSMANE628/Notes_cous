let titres = document.getElementsByClassName('titre');
let paragraphes = document.getElementsByClassName('paragraphe');

function afficherparagraphe(i){
    paragraphes[i].classList.add('visible');
}

function cacherparagraphe(){
    for(let i =0; i < paragraphes.length; i++){
        paragraphes[i].classList.remove('visible')
    }  
}

function afficher(i){
    return function(){
        cacherparagraphe();
        afficherparagraphe(i);
        
    }
}

for (let i = 0; i < titres.length; i++) {
    titres[i].onclick = afficher(i);
}








// let tit = document.getElementsByClassName('titre');
// let parag = document.getElementsByClassName('paragraphe');

// function affichparag(i){
//     parag[i].classList.add('visible');
// }

// function cacheparag(){
//     for(let i = 0; i < parag.length; i++){
//         parag[i].classList.remove('visible');
//     }
// }

// function affichertous(){
//     return function(){
//         cacheparag();
//         affichparag(i);
        
//     }
// }

// for(let i = 0; i< tit.length; i++){
//     tit[i].onclick = affichertous(i);
// }
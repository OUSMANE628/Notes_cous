Comment ouvrir la console JavaScript dans Google Chrome ?

    Ctrl-Shift-J

Que retourne typeof quand il est appliqué sur "bonjour" ?

    "string"

Types de valeurs en JavaScript. Quel est l'intrus ?

    decimal
   

Comment créer une variable en JavaScript ?

    var maVariable;

Comment afficher la valeur d'une variable appelée maVariable depuis la console ?

    maVariable;

Comment changer la valeur d'une variable existante ? (déjà créée)

    maVariable = 4;

Si j'ai créé une variable dont la valeur est un nombre, que se passera-t-il si je lui affecte ensuite une chaine de caractères ?

    erreur, car le type est différent.

---
# TP2

Quel section va être exécutée, si on exécute le code suivant ?
```js
var nb = 2;
if (nb === 1) {
// A
} else {
// B
}
```
 B 

Quel section de va être exécutée, si on exécute le code suivant ?
```js
var nb = 2;
if (nb === 2) {
// A
} else if (nb > 1) {
// B
} else {
// C
}
```
    A, B et C

    À quoi ressemblerait l'arbre de décision correspondant à ce code:
    ```js
    var reponse = prompt('as-tu faim ?')
    if (reponse === 'oui') {
    var reponse2 = prompt('aimes-tu les burgers ?');
    if (reponse2 === 'oui') {
    alert('alors je t\'en offre un !');
    } else {
    alert('dommage !');
    }
    } else {
    alert('désolé');
    }
    ```
        une boîte et deux branches
       
    
    Pourquoi faut-il éviter d'utiliser les opérateurs == et != ?
    
        car il vaut mieux utiliser une affectation =
        car ils sont trop stricts
        car ils sont trop laxistes
        var === et !== sont plus lisibles
    
    Implémenter une condition qui affecte 'egal' à une variable resultat seulement si
    une autre variable nombre vaut strictement 4 . Indenter correctement.
    ```js
    Saisissez votre code Javascript ici
    ```
    
    ---
    # TP3
    Combien de fois les instructions vont-elles être exécutées ?
    ```js
    for ( var i = 0; i < 4; i++ ) {
    // instructions
    }
    ```
        0 fois
        1 fois
        3 fois
        4 fois
    
    Combien de fois les instructions vont-elles être exécutées ?
    ```js
    for ( var i = 3; i >= 1; i-- ) {
    // instructions
    }
    ```
        0 fois
        1 fois
        3 fois
        4 fois
    
    Implémenter un programme de moins de 4 lignes qui affiche 50 fois 'Bonjour!'
    dans la console. Respecter les conventions et règles d'indentation vues en cours.
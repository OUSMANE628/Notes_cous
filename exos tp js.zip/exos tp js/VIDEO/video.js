let videos = [
    'https://www.youtube.com/embed/0uaQMxBjd5E',
    'https://www.youtube.com/embed/c8ZPn6p5khI',
    'https://www.youtube.com/embed/ikkrEOD1BbQ',
];

let video = document.getElementById('video');
let bouton = document.getElementById('bouton');

function pourAfficherVideo(i){
    return function(){
        video.innerHTML = '<iframe width="320" height ="200" src="' + videos[i] + '?autoplay=1"></iframe>'
    };
  }
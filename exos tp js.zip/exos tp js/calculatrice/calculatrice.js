
function calculate(){
    let bmi;
    let resultat = document.getElementById('resultat');
    let poid = parseInt(document.getElementById('poid').value);
    let taille = parseInt(document.getElementById('taille').value);

    bmi =(poid /Math.pow((taille/100),2)).toFixed(1);
    resultat.textContent = bmi;

    if(bmi <18.5){
        category = 'faible_poid';
        resultat.styleColor ='green';

    }else if(bmi >=18.5 && bmi <= 24.9){
        category = 'poid_normal';
        resultat.styleColor ='bleu';

    } else if( bmi >= 25 && bmi <= 29.9 ){
        category = "poid_depassé";
        resultat.style.color = "orange";
    }
    else{
        category = "Obese";
        resultat.style.color = "red";
    }
    document.getElementById("category").textContent = category;
}

document.getElementById('poid').oninput = function (){
    calculate()
}

document.getElementById('taille').oninput = function (){
    calculate()
}
